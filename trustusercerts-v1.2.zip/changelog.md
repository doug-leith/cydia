# v1.2

* Change module description
* Support add certificate into folder /data/adb/trustusercerts/certificates instead of have to install as user certificate
* Change module log into magisk console

# v1.1

Fix wrong update url in module.prop

# v1.0

Initial Release